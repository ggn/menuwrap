var $routerApp = angular.module('Menuwrap', ['ui.router']);

$routerApp.directive('a', function () {
    return {
        restrict: 'E',
        link: function (scope, elem, attrs  ) {
            if (attrs.ngClick || attrs.href === '' || attrs.href === '#') {
                elem.on('click', function (e) {
                    e.preventDefault();
                });
            }
        }
    };
});

//$routerApp.config(function ($routeProvider, $httpProvider) {
//    $routeProvider.when("/", {
//        templateUrl: "Views/Account/login.html",
//        controller: "loginController",
//    }).when("/login", {
//        templateUrl: "Views/Account/login.html",
//        controller: "loginController",
//    }).when("/signup", {
//        templateUrl: "Views/Account/signup.html",
//        controller: "signupcontroller",
//    }).when("/dashboard", {
//        templateUrl: "Views/Dashboard/dashboard.html",
//        controller: "dashboardcontroller",
//        requiresLogin: true
//    }).when("/pushNotifocation", {
//        templateUrl: "Views/Patient/pushnotification.html",
//        controller: "dashboardcontroller",
//        requiresLogin: true
//    }).when("/verify/:id?", {
//        templateUrl: "Views/Account/verify.html",
//        controller: "verifycontroller",
//    }).when("/registered", {
//        templateUrl: "Views/Account/registrationSuccessful.html",
//        controller: "",
//    }).when("/verified", {
//        templateUrl: "Views/Account/verificationSuccessful.html",
//        controller: "",
//    }).otherwise({ redirectTo: '/' });
//}).run(['$rootScope', '$location', 'AuthService', function ($rootScope, $location, AuthService) {
//    $rootScope.$on('$routeChangeStart', function (event, next) {
//        if (next.requiresLogin && !AuthService.isAuthenticated()) {
//            console.log('Unauthorised User');
//            event.preventDefault();
//            $location.path('/login');
//        } else {
//            return $location.path;
//        }
//    });
//}]);




