var $PortalApp = angular.module('Menuwrap');
$PortalApp.controller('globalController', function ($scope, AuthService, $location) {

});

